#Overview
An advanced analytical tool using Microsoft Power BI and Azure DevOps to provide in-depth insights into Netflix's content library.

#Features
*Total Titles and Ratings: Distribution across different rating categories.

*Genre Analysis: Breakdown of shows by genre.

*Director Insights: Data on directors and their contributions.

*Temporal Distribution: Release dates of content from 1920 to 2021.

*Geographical Distribution: Mapping of shows by country.

*Content Type Distribution: Segmentation into movies and TV shows.

*Rating Distribution: Availability of content for different audience age groups.
#Prerequisites
*Microsoft Power BI Desktop

*Azure DevOps Account

*Netflix dataset (Excel, CSV, or SQL Server)
#Setup
1)Data Preparation

2)Gather and clean the Netflix dataset.

3)Preprocess using tools like Python, Excel, or directly in Power BI.
#Creating the Dashboard in Power BI
1)Install Power BI Desktop.

2)Load the dataset into Power BI.

3)Create visualizations and format the dashboard.

4)Save the Power BI report file (.pbix).
#Setting Up Azure DevOps
1)Create an Azure DevOps Account.

2)Create a new project.

3)Initialize and clone the repository.

4)Commit and push the Power BI files.
#License
This project is licensed under the MIT License. See the LICENSE file for details.

#Contact
For questions or feedback, 

please contact:
Alolika Bhowmik

Email: alolikabhowmik72@gmail.com